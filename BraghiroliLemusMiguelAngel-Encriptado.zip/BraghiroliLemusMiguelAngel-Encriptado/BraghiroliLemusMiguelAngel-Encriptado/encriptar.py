 #Miguel Braghiroli Encriptado
from cryptography. fernet import Fernet
texto=input ("introduzca texto a encriptar:")
print(texto)
llave = Fernet.generate_key()
objeto= Fernet (llave)
encriptado=objeto.encrypt(str.encode(texto))
print ("El texto encriptado es igual a:'", encriptado)

desencriptado=objeto.decrypt(encriptado)
print(desencriptado)
texto_desencriptado-desencriptado.decode()
print("El texto desencriptado es igual a:",texto_desencriptado)